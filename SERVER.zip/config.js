export const jwtSecret = '1Ewe9920';
