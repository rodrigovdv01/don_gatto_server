import { DataTypes } from "sequelize";
import db from "../database/db.js";

const Pedido = db.define(
  "pedidos",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    nombre: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    direccion_envio: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    telefono: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING
    },
    monto_total: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    estado_pedido: {
      type: DataTypes.ENUM('Activo', 'En camino', 'Finalizado'),
      allowNull: false,
    },
    
  },
  {
    tableName: "pedidos", // Nombrre real de la tabla en la base de datos
  }
);

export default Pedido;
